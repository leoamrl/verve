<div class="container">
  <section class="page-hero">
    <h1 class="page-hero-title"><?php the_title() ?></h1>
  </section>
</div>