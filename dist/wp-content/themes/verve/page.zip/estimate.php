<?php

/*
Template Name: Estimate
*/

get_header();

  include get_theme_file_path( '/views/page/hero.php' );
  include get_theme_file_path( '/views/estimate/content.php' );

get_footer();