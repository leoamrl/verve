<?php get_header();

  include get_theme_file_path( '/views/blog/hero.php' );
  include get_theme_file_path( '/views/blog/single.php' );

get_footer();