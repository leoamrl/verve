<?php get_header();

  include get_theme_file_path( '/views/blog/hero.php' );
  include get_theme_file_path( '/views/blog/list.php' );

get_footer();