<?php get_header(); ?>

  <div class="container">
    <?php include get_theme_file_path( '/views/page/not_found.php' ); ?>
  </div>

<?php get_footer();