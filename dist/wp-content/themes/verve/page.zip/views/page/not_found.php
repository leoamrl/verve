<section class="page-notFound content">
  <h1 class="page-notFound-title">404</h1>
  <h2 class="page-notFound-subtitle">Não econtramos o que você esperava.</h2>
</section>