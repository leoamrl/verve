<?php get_header();

  include get_theme_file_path( '/views/home/hero.php' );
  include get_theme_file_path( '/views/home/clients.php' );
  include get_theme_file_path( '/views/home/about.php' );
  include get_theme_file_path( '/views/home/numbers.php' );
  include get_theme_file_path( '/views/home/services.php' );
  // include get_theme_file_path( '/views/home/cases.php' );
  include get_theme_file_path( '/views/home/testimonials.php' );
  include get_theme_file_path( '/views/home/faqs.php' );
  // include get_theme_file_path( '/views/home/blog.php' );
  include get_theme_file_path( '/views/home/contact.php' );

get_footer();