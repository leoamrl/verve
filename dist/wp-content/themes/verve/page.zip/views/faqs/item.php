<article class="faqs-item">
  <a href="<?php the_permalink() ?>">
    <header class="faqs-item-title">
      <h1 class="faqs-item-question"><?php the_title() ?></h1>
      
      <div class="faqs-item-caption">
        <span class="expand"><i class="fa fa-chevron-right"></i></span>
      </div>
    </header>
  </a>
</article>