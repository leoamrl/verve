<?php get_header();

  include get_theme_file_path( '/views/faqs/single.php' );
  include get_theme_file_path( '/views/faqs/form.php' );

get_footer();